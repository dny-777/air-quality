import { Wind, Droplet, Zap, CloudRain } from "lucide-react";
import { AQICard } from "./AQICard";
import { AQIMap } from "./AQIMap";
import { ForecastChart } from "./ForecastChart";
import { WeatherCard } from "./WeatherCard";
import { AlertBanner } from "./AlertBanner";

export function Dashboard() {
  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      {/* Alert Banner */}
      <AlertBanner
        title="⚠️ Unhealthy Air Expected Tomorrow"
        message="Air quality is forecasted to reach unhealthy levels tomorrow afternoon in Delhi. Sensitive groups should limit outdoor activities."
        severity="warning"
      />

      {/* AQI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <AQICard
          title="PM2.5"
          value={12.5}
          unit="μg/m³"
          icon={Droplet}
          level="good"
          description="Fine particulate matter (PM2.5) are tiny particles in the air that reduce visibility and can affect your lungs and heart health."
          trend="down"
        />
        <AQICard
          title="PM10"
          value={28}
          unit="μg/m³"
          icon={CloudRain}
          level="good"
          description="PM10 are inhalable particles with diameters of 10 micrometers or smaller. They can cause respiratory issues when inhaled."
          trend="stable"
        />
        <AQICard
          title="Ozone (O₃)"
          value={45}
          unit="ppb"
          icon={Zap}
          level="good"
          description="Ground-level ozone is created by chemical reactions between nitrogen oxides and volatile organic compounds in sunlight. It can trigger respiratory problems."
          trend="up"
        />
        <AQICard
          title="NO₂"
          value={18}
          unit="ppb"
          icon={Wind}
          level="good"
          description="Nitrogen dioxide (NO₂) is a gas produced by burning fuel. High concentrations can irritate airways in the respiratory system."
          trend="stable"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map - Takes 2 columns on large screens */}
        <div className="lg:col-span-2">
          <AQIMap />
        </div>

        {/* Weather Card */}
        <div>
          <WeatherCard />
        </div>
      </div>

      {/* Forecast Chart - Full Width */}
      <ForecastChart />

      {/* Info Section */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-6 border border-blue-200">
        <h3 className="mb-2">💡 Quick Tips for Today</h3>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• Air quality is currently <span className="text-green-600 font-semibold">Good</span> - Perfect for outdoor activities!</li>
          <li>• Morning (6-10 AM) is the best time for exercise with lowest pollution levels</li>
          <li>• Keep windows open to improve indoor air circulation</li>
          <li>• Check back tomorrow afternoon when AQI may rise to moderate levels</li>
        </ul>
      </div>
    </div>
  );
}